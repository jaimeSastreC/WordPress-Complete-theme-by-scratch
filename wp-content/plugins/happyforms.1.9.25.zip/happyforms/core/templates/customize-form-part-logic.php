<div class="no-parts no-parts--show no-parts--small">
	<h3><?php _e( 'Logic', 'happyforms' ); ?></h3>

	<p class="description"><a href="https://happyforms.me/upgrade" target="_blank" class="external"><?php _e( 'Upgrade to add logic rule', 'happyforms' ); ?></a></p>
</div>
