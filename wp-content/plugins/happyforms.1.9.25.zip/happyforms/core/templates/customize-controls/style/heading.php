<li class="customize-control happyforms-customize-heading" id="customize-heading-<?php echo $control['id']; ?>">
	<h2><?php echo $control['label']; ?></h2>
</li>