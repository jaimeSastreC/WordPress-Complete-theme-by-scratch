<?php 
    /* Ajout emplacement de menu */

    if (function_exists('register_nav_menus')){
        register_nav_menus(
            [
                'menu principal' => 'menu haut de page',
                'footer' => 'menu bas de page',
            ]
        );
    }

    /* Ajout emplacement de la sidebar */
    if (function_exists('register_sidebar')){
        register_sidebar();
    }