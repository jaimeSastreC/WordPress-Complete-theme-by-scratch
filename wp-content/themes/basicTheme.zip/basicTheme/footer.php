        </div>
        <footer>
            <h2><?php bloginfo('description'); ?></h2>
        </footer>
    </body>
</html>